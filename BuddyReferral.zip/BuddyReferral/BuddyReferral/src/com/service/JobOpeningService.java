package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.connection.DBConnection;
import com.dao.JobOpeningDao;
import com.model.JobOpening;

public class JobOpeningService implements JobOpeningDao{
	
	public boolean addJobOpening(JobOpening jo) {
		boolean isJobOpeningAdded = false;
		Connection con=null;
		PreparedStatement ps =null;
		System.out.println("Logger >>> inside Add JobOpening Method @ JobOpeningDao ");
		try {
			con=DBConnection.getConnection();
			ps=con.prepareStatement("insert into JobOpening (skills,experience,location,spocName,email_id,rewards) values (?,?,?,?,?,?)");
			ps.setString(1, jo.getSkills());
			ps.setInt(2, jo.getExperience());
			ps.setString(3, jo.getJobLocation());
			ps.setString(4, jo.getSpocName());
			ps.setString(5, jo.getEmailID());
			ps.setInt(6, jo.getRewards());
			int resultRowCount = ps.executeUpdate();
			if(resultRowCount == 1)
				isJobOpeningAdded = true;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally
		{
			try{
				con.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
		}
		return isJobOpeningAdded;

	}

	public boolean removeJobOpening(int jobCode) {
		Connection con=null;
		PreparedStatement ps =null;
		boolean isJobOpeningDeleted = false;
		System.out.println("Logger >>> inside removeJobOpening method @ JobOpeningDaoImpl");
		try {
			
			con=DBConnection.getConnection();
			ps=con.prepareStatement("Delete from JobOpening where jobCode=?");
			ps.setInt(1, jobCode);
			int del = ps.executeUpdate();
			if(del == 1)
				isJobOpeningDeleted = true;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally
		{
			try{
				con.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
		}
	    return isJobOpeningDeleted;
	}

	public boolean updateJobOpening(JobOpening jo) {
		Connection con=null;
		PreparedStatement ps =null;
		ResultSet rs = null;
//		JobApplication jobApplication = null;
		boolean isJobOpeningUpdated = false;

		System.out.println("Logger >>> inside updateJobOpening Method @ JobOpeningDao");
		try {
			con=DBConnection.getConnection();
			ps=con.prepareStatement("Update jobappplication SET  skills= ?,experience=?,jobLocation=?,spocName=?,emailID=?,rewards=? where jobCode=?");
			ps.setString(1, jo.getSkills());
			ps.setInt(2, jo.getExperience());
			ps.setString(3, jo.getJobLocation());
			ps.setString(4, jo.getSpocName());
			ps.setString(5, jo.getEmailID());
			ps.setInt(6, jo.getRewards());
			
			ps.setInt(7, jo.getJobCode());
			int editStatusResult = ps.executeUpdate();
			if(editStatusResult == 1)
				isJobOpeningUpdated = true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally
		{
			try{
				con.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
		}
	    return isJobOpeningUpdated;
	}

	public ArrayList<JobOpening> showJobOpenings(String isStatusFinal) {
		// TODO Auto-generated method stub
		return null;
	}

	public Double calculateReward(int jobCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
