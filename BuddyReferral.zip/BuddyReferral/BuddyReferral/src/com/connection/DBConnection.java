package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	static Connection con=null;

	static Connection con1=null;



	public static Connection getConnection()

	{



	try {

	Class.forName("oracle.jdbc.driver.OracleDriver");

	con=DriverManager.getConnection("jdbc:oracle:thin:@10.53.13.46:1521:xe","BRP","1234");

	} catch (ClassNotFoundException e) {



	e.printStackTrace();

	} catch (SQLException e) {

	e.printStackTrace();

	}

	return con;

	}

	public static void closeConection()

	{

	if(con!=null)

	try {

	con.close();

	} catch (SQLException e) {



	e.printStackTrace();

	}

	}
}
